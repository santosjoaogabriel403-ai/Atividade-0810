package br.edu.pfc.loginseguro.user;

public enum Role { USER, MODERATOR, ADMIN }
