package br.edu.pfc.loginseguro.web;

import br.edu.pfc.loginseguro.user.RegistrationForm;
import br.edu.pfc.loginseguro.user.UserService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController {
    private final UserService users;
    public AuthController(UserService users) { this.users = users; }
    @GetMapping({"/", "/login"}) String login() { return "login"; }
    @GetMapping("/cadastro") String registration(Model model) { model.addAttribute("form", new RegistrationForm()); return "cadastro"; }
    @PostMapping("/cadastro") String register(@Valid RegistrationForm form, BindingResult result, Model model) {
        if (result.hasErrors()) return "cadastro";
        try { users.register(form); return "redirect:/login?cadastrado"; }
        catch (UserService.EmailAlreadyUsedException ex) { model.addAttribute("emailDuplicado", true); return "cadastro"; }
    }
    @GetMapping("/painel") String dashboard() { return "painel"; }
    @GetMapping("/moderacao") String moderation() { return "moderacao"; }
    @GetMapping("/admin") String admin() { return "admin"; }
}
