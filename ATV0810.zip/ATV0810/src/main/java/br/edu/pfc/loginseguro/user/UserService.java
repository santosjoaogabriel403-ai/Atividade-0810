package br.edu.pfc.loginseguro.user;

import java.util.Set;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {
    private final UserRepository users; private final PasswordEncoder encoder;
    public UserService(UserRepository users, PasswordEncoder encoder) { this.users = users; this.encoder = encoder; }
    public AppUser register(RegistrationForm form) {
        String email = form.getEmail().trim().toLowerCase();
        if (users.existsByEmail(email)) throw new EmailAlreadyUsedException();
        return users.save(new AppUser(form.getName().trim(), email, encoder.encode(form.getPassword()), Set.of(Role.USER)));
    }
    public static class EmailAlreadyUsedException extends RuntimeException { }
}
