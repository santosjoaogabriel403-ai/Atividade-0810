package br.edu.pfc.loginseguro.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@Configuration
@EnableConfigurationProperties(ThemeProperties.class)
class ThemeConfiguration { }

@ControllerAdvice
class ThemeAdvice {
    private final ThemeProperties properties;
    ThemeAdvice(ThemeProperties properties) { this.properties = properties; }
    @ModelAttribute("theme") String theme() { return properties.getActive(); }
}
