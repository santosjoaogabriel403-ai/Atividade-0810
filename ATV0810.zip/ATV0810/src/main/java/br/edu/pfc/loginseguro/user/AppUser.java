package br.edu.pfc.loginseguro.user;

import java.time.Instant;
import java.util.Set;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("users")
public class AppUser {
    @Id private String id;
    private String name;
    @Indexed(unique = true) private String email;
    private String passwordHash;
    private Set<Role> roles;
    private Instant createdAt;
    private boolean enabled = true;
    protected AppUser() { }
    public AppUser(String name, String email, String passwordHash, Set<Role> roles) {
        this.name = name; this.email = email; this.passwordHash = passwordHash; this.roles = roles; this.createdAt = Instant.now();
    }
    public String getId() { return id; } public String getName() { return name; }
    public String getEmail() { return email; } public String getPasswordHash() { return passwordHash; }
    public Set<Role> getRoles() { return roles; } public Instant getCreatedAt() { return createdAt; }
    public boolean isEnabled() { return enabled; }
}
