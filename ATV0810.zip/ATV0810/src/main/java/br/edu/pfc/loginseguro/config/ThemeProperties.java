package br.edu.pfc.loginseguro.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app.theme")
public record ThemeProperties(String active) { public String getActive() { return active == null ? "padrao" : active; } }
