# INSTITUIÇÃO DE ENSINO

## CURSO

### NOME DO(A) AUTOR(A)

# LOGIN SEGURO: AUTENTICAÇÃO MODULAR COM SPRING BOOT E MONGODB ATLAS

Trabalho técnico de referência para adaptação ao Projeto Final de Curso.

Cidade  
2026

## RESUMO

Este documento descreve um sistema de autenticação web modular construído com Java, Spring Boot, Spring Security, Thymeleaf e MongoDB Atlas. A aplicação oferece cadastro, login, logout, armazenamento de senhas com BCrypt, autorização por papéis e persistência de sessões. A separação entre domínio de usuários, configuração de segurança, controladores, templates e estilos permite adaptar a identidade visual e integrar o sistema a diferentes temas de Projeto Final de Curso sem reescrever o fluxo central de autenticação. As credenciais de banco são fornecidas por variáveis de ambiente. Apresentam-se a arquitetura, a configuração do Atlas, as decisões de segurança e as orientações para evolução.

**Palavras-chave:** autenticação; autorização; Spring Security; MongoDB Atlas; Thymeleaf.

## 1 INTRODUÇÃO

Sistemas web que mantêm contas precisam identificar usuários e restringir operações de acordo com permissões. Este projeto apresenta uma base reutilizável para autenticação e autorização, mantendo os elementos de apresentação separados da regra de negócio. O escopo inclui criação de conta, autenticação, encerramento de sessão, perfis `USER`, `MODERATOR` e `ADMIN`, armazenamento de usuários e sessões em MongoDB e configuração de temas.

O sistema é uma base acadêmica de referência. Para uso real, devem ser definidas políticas adicionais, como recuperação de senha, verificação de e-mail, proteção contra abuso automatizado, auditoria e governança de administradores.

## 2 OBJETIVOS

### 2.1 Objetivo geral

Disponibilizar uma estrutura genérica de login seguro que possa ser integrada a um PFC com mudanças concentradas no domínio e na apresentação.

### 2.2 Objetivos específicos

- Implementar cadastro, login e logout gerenciados pelo Spring Security.
- Persistir usuários e sessões no MongoDB Atlas.
- Aplicar BCrypt às senhas e validar os dados de cadastro.
- Restringir páginas conforme três perfis de autorização.
- Manter templates e estilos substituíveis por configuração.

## 3 PROCEDIMENTOS METODOLÓGICOS

Foi adotada uma arquitetura em camadas com framework Java e persistência documental. O Spring Security controla o ciclo de autenticação, proteção CSRF, autorização por rota e gerenciamento da sessão. O Spring Data MongoDB fornece acesso à coleção de usuários; Spring Session Data MongoDB persiste sessões HTTP. Thymeleaf processa páginas e fragmentos reutilizáveis. A configuração externa recebe segredos por variáveis de ambiente.

## 4 ESTRUTURA DO SISTEMA

O pacote `user` contém o documento `AppUser`, a enumeração `Role`, o repositório, o serviço de cadastro, a validação do formulário e a implementação de `UserDetailsService`. O pacote `config` reúne a cadeia de filtros de segurança e a propriedade que seleciona o tema ativo. O pacote `web` contém os controladores MVC. Em recursos, `templates` mantém páginas e fragmentos Thymeleaf e `static/css` mantém folhas de estilo.

O cadastro atribui exclusivamente o papel `USER`; o formulário não aceita papéis fornecidos pelo cliente. A concessão de privilégios é uma operação administrativa controlada. Essa decisão impede elevação de permissão no fluxo público.

### 4.1 Rotas protegidas

As páginas de login, cadastro e arquivos estáticos são públicas. O painel requer autenticação. A área `/moderacao` requer `MODERATOR` ou `ADMIN`; `/admin` exige `ADMIN`. O projeto habilita segurança em métodos para que serviços futuros também recebam restrições explícitas.

### 4.2 Temas visuais

`APP_THEME` seleciona o arquivo CSS carregado pelos templates. O projeto inclui os temas `padrao` e `noite`. Para adaptar a identidade visual, cria-se uma folha CSS e configura-se o nome correspondente, sem mudar o modelo de usuários. Fragmentos Thymeleaf também podem ser personalizados mantendo os contratos de atributos e rotas.

## 5 INTEGRAÇÃO COM O MONGODB ATLAS

No Atlas, cria-se um cluster e um database user com acesso mínimo ao banco da aplicação. A string `mongodb+srv` do Atlas é definida em `MONGODB_URI`; `MONGODB_DATABASE` define o banco, por padrão `login_seguro`. O Spring Boot conecta-se usando TLS do driver e endpoint Atlas. A aplicação não contém URI nem senha reais versionadas.

A coleção `users` contém nome, e-mail normalizado, hash de senha, conjunto de papéis, estado da conta e data de criação. A coleção `sessions`, configurada por Spring Session, armazena as sessões HTTP para que o estado de autenticação sobreviva às requisições e seja gerenciado pela aplicação. A criação automática de índices está ligada no protótipo para permitir o índice único de e-mail; equipes devem planejar índices como parte do processo operacional em produção.

Para desenvolvimento, a lista de acesso de rede do Atlas deve permitir somente o IP necessário. O usuário do banco deve ter privilégio mínimo. Em ambiente publicado, segredos devem ficar no gerenciador da plataforma, cookies devem usar HTTPS (`COOKIE_SECURE=true`) e o acesso ao cluster deve permanecer restrito.

## 6 DECISÕES DE SEGURANÇA E DESIGN

BCrypt com fator 12 transforma a senha antes da persistência. A validação exige nome, e-mail sintaticamente válido e senha com pelo menos 12 caracteres; o erro de autenticação não revela qual campo falhou. O Spring Security mantém CSRF ativo nos formulários e fornece o campo oculto automaticamente ao Thymeleaf. Após autenticação, o ID de sessão é alterado para reduzir risco de fixação. O logout invalida a sessão e remove o cookie `SESSION`.

O cookie é `HttpOnly` e `SameSite=Lax`; `Secure` é configurável porque desenvolvimento local HTTP e produção HTTPS têm necessidades distintas. O limite de três sessões simultâneas reduz sessões abandonadas. Essas medidas não substituem TLS no deploy, gestão de segredos, monitoramento, retenção, revisão de dependências ou processo seguro de recuperação de conta.

A camada visual conhece rotas e atributos de apresentação, mas não implementa regras de senha ou autorização. Essa separação reduz o custo de aplicar identidade visual de um PFC futuro.

## 7 EXECUÇÃO LOCAL

Instale JDK 21 e Maven, crie o cluster e usuário Atlas e configure `MONGODB_URI`, `MONGODB_DATABASE`, `APP_THEME` e `COOKIE_SECURE` no ambiente local. Execute `mvn spring-boot:run` na pasta e acesse `http://localhost:8080`. O `.env.example` lista as variáveis, mas nenhum segredo real deve ser adicionado ao repositório. O README contém comandos para o terminal do VS Code.

## 8 ADAPTAÇÃO FUTURA AO PFC

Para personalizar, configure `APP_THEME` e crie um CSS correspondente; altere fragmentos e textos em `templates`; adicione entidades específicas do PFC em pacotes próprios. Os dados do projeto devem referenciar o usuário por identificador ou e-mail imutável, sem duplicar credenciais. Novas permissões devem ser adicionadas à enumeração e às regras de autorização, sempre com menor privilégio.

Antes de implantação institucional, recomenda-se incorporar verificação de e-mail, recuperação com tokens de uso único e validade curta, limitação de tentativas, auditoria de operações privilegiadas, política de retenção de sessões e revisão por responsável de segurança.

## 9 CONSIDERAÇÕES FINAIS

O sistema reúne autenticação, autorização por papéis, persistência de usuários e sessões no MongoDB Atlas e templates configuráveis numa estrutura reutilizável. O cadastro público é limitado a contas comuns, as senhas não são persistidas em texto claro e a interface está isolada da lógica de autenticação. Para entrega acadêmica, este modelo deve ser completado com dados bibliográficos e institucionais do autor e validado frente às orientações formais da instituição.

## REFERÊNCIAS

MONGODB. **MongoDB Atlas Documentation**. Disponível em: <https://www.mongodb.com/docs/atlas/>. Acesso em: 7 out. 2026.

SPRING. **Spring Security Reference**. Disponível em: <https://docs.spring.io/spring-security/reference/>. Acesso em: 7 out. 2026.

SPRING. **Spring Boot Reference Documentation**. Disponível em: <https://docs.spring.io/spring-boot/>. Acesso em: 7 out. 2026.

THYMELEAF. **Thymeleaf Documentation**. Disponível em: <https://www.thymeleaf.org/documentation.html>. Acesso em: 7 out. 2026.
