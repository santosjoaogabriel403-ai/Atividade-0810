# Login Seguro

Aplicação de referência para autenticação e autorização com Java 21, Spring Boot, Spring Security, Thymeleaf e MongoDB Atlas. A lógica é genérica para receber conceitos de domínio do PFC sem acoplar segurança a um tema específico.

## Requisitos locais

- Java 21 (JDK)
- Maven 3.9+
- Conta MongoDB Atlas e database `login_seguro`
- VS Code com Extension Pack for Java e Spring Boot Extension Pack (opcionais, recomendados)

## Configurar o Atlas

1. Crie um cluster no Atlas e um database user com senha forte e privilégio mínimo `readWrite` no database `login_seguro`.
2. Em Network Access, permita o IP de desenvolvimento. Evite `0.0.0.0/0` fora de testes controlados.
3. Copie a connection string `mongodb+srv` de **Connect → Drivers**. Codifique caracteres especiais na senha conforme URL encoding.
4. No terminal integrado do VS Code, defina as variáveis (não coloque segredos no Git):

   ```powershell
   $env:MONGODB_URI="mongodb+srv://USUARIO:SENHA@SEU-CLUSTER.mongodb.net/login_seguro?retryWrites=true&w=majority&appName=login-seguro"
   $env:MONGODB_DATABASE="login_seguro"
   $env:APP_THEME="padrao"
   $env:COOKIE_SECURE="false"
   ```

   `.env.example` documenta os nomes, mas Spring Boot não carrega esse arquivo automaticamente. Em deploy HTTPS, configure `COOKIE_SECURE=true`.

5. Inicie:

   ```powershell
   mvn spring-boot:run
   ```

   Acesse http://localhost:8080.

## Rotas e perfis

| Rota | Acesso |
|---|---|
| `/`, `/login`, `/cadastro` | Público |
| `/painel` | Usuário autenticado |
| `/moderacao` | `MODERATOR` ou `ADMIN` |
| `/admin` | `ADMIN` |

O cadastro público sempre cria somente `USER`. Para promover uma conta, confirme o e-mail por processo administrativo e altere a função pelo Atlas Data Explorer ou `mongosh`, no banco `login_seguro`:

```javascript
db.users.updateOne({email: "operador@exemplo.com"}, {$addToSet: {roles: "ADMIN"}})
```

Nunca exponha uma rota pública que permita escolher um papel privilegiado. Os papéis válidos são `USER`, `MODERATOR` e `ADMIN`.

## Persistência e segurança

- A coleção `users` guarda e-mail normalizado, nome, roles e hash BCrypt (custo 12); senha em texto puro não é persistida.
- A coleção `sessions` é mantida por Spring Session Data MongoDB. O cookie usa `HttpOnly`, `SameSite=Lax`; marque `Secure` em HTTPS.
- Spring Security mantém CSRF habilitado, troca o ID da sessão após login, limita a três sessões concorrentes e invalida a sessão no logout.
- A criação automática de índices facilita o protótipo. Em produção, gerencie índices em migrações operacionais.
- Use usuário MongoDB com privilégio mínimo, TLS padrão Atlas, segredo fora do repositório e allowlist de rede.

## Estrutura modular e temas

`user` contém modelo, repositório, serviço e UserDetails; `config` contém segurança e seleção de tema; `web` reúne controladores; `templates` contém páginas e fragmentos Thymeleaf; `static/css` contém folhas intercambiáveis. `APP_THEME` seleciona `padrao` ou `noite`. Novos temas podem adicionar CSS sem alterar autenticação.

## VS Code

Abra esta pasta (`File → Open Folder`), aguarde a importação Maven, defina as variáveis no terminal integrado e rode `mvn spring-boot:run`.

## Gitflow e GitHub

Use `main` para versões estáveis, `develop` para integração e branches `feature/<assunto>` para mudanças. Abra pull requests de feature para `develop` e promova versões para `main` com tags. Revise `git status` antes de publicar e confirme que `.env`, connection strings e credenciais não entram no commit. Crie um repositório público independente e use o remote pessoal após confirmar a URL.

## Documentação

Consulte `docs/documentacao-abnt.pdf` e `docs/documentacao-abnt.md` para arquitetura, integração Atlas e decisões de design. Preencha instituição, autor, curso e cidade antes da entrega formal e confira as exigências específicas da instituição.
